CREATE  PROCEDURE `FindSearchWordinBlogs`(SearchWord nvarchar(50))
BEGIN
SELECT id, description	
FROM Blogs
	 WHERE   description LIKE CONCAT( N'% ', SearchWord)
	  or description LIKE   CONCAT( SearchWord,' %')  
	  or description LIKE  CONCAT(CHAR(13), CHAR(10), SearchWord,' %')  
	  or description LIKE  CONCAT(N'%',CHAR(13), CHAR(10), SearchWord,CHAR(13),CHAR(10),'%')  
	  or description like  CONCAT( N'% ',SearchWord,CHAR(13), CHAR(10),'%')  
	  or description LIKE  CONCAT( N'% ',SearchWord, ' %') 
	  or description LIKE CONCAT( N'%"',SearchWord,  '"%') 
	  or description LIKE  CONCAT( N'%"',SearchWord,  ' %')  
	  or description LIKE CONCAT( N'% ',SearchWord,  '"%')   ;
END